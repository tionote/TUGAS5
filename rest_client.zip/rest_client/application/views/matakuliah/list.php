<html>
<title> Data Mata Kuliah </title>
<h1 style="background-color:DodgerBlue" align="center">UNIVERSITAS STIKUBANK SEMARANG <br> TAHUN PELAJARAN 2018 <br> SISTEM INFORMASI AKADEMIK </h1> 

<body style="background-color:#b3ccff">

<center><h2>DATA MAHASISWA UNIVERSITAS STIKUBANK</h2>
<h3>TAHUN AJARAN 2017/2018</h3></center><br>
<?php echo $this->session->flashdata('hasil'); ?>
<table align=center border=1>
    <tr><th>KODE</th><th>MATA KULIAH</th><th></th></tr>
    <?php
    foreach ($matakuliah as $m){
        echo "<tr>
              <td>$m->kode</td>
              <td>$m->matakuliah</td>
              <td>
                  ".anchor('matakuliah/edit/'.$m->kode,'Edit')."
                  ".anchor('matakuliah/delete/'.$m->kode,'Delete')."</td>
              </tr>";
    }
	echo "<tr>
				<td>".anchor('matakuliah/create/'.$m->kode,'Tambah Data')."</td>
				</tr>";
    ?>
</table>
<h4 style="background-color:DodgerBlue" align="center">Listyani Praptining P (15.01.53.0013) <br> Apriana Panca K (15.01.53.0065) <br> Fadilla Maulida (15.01.53.0082)</h4> 
</body> </center>
</html>