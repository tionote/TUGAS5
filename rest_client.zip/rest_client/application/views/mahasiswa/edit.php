<html>
<title> Edit Data Mahasiswa </title>
<h1 style="background-color:DodgerBlue" align="center">UNIVERSITAS STIKUBANK SEMARANG <br> TAHUN PELAJARAN 2018 <br> SISTEM INFORMASI AKADEMIK </h1> 
<h1><center> Tambah Data Mahasiswa </h1>
<body style="background-color:#b3ccff">
<?php echo form_open('mahasiswa/edit');?>
<?php echo form_hidden('nim',$mahasiswa[0]->nim);?>
 
<table align="center">
    <tr><td>NIM</td><td><?php echo form_input('',$mahasiswa[0]->nim,"disabled");?></td></tr>
    <tr><td>NAMA</td><td><?php echo form_input('nama',$mahasiswa[0]->nama);?></td></tr>
    <tr><td>PRODI</td><td><?php echo form_input('prodi',$mahasiswa[0]->prodi);?></td></tr>
    <tr><td>ALAMAT</td><td><?php echo form_input('alamat',$mahasiswa[0]->alamat);?></td></tr>
    <tr><td colspan="2" align="center">
        <?php echo form_submit('submit','Simpan');?>
        <?php echo anchor('mahasiswa','Kembali');?></td></tr>
</table>
<?php
echo form_close();
?>
<h4 style="background-color:DodgerBlue" align="center">Listyani Praptining P (15.01.53.0013) <br> Apriana Panca K (15.01.53.0065) <br> Fadilla Maulida (15.01.53.0082)</h4> 
</body> </center>
</html>