<html>
<title> Tambah Data Mahasiswa </title>
<h1 style="background-color:DodgerBlue" align="center">UNIVERSITAS STIKUBANK SEMARANG <br> TAHUN PELAJARAN 2018 <br> SISTEM INFORMASI AKADEMIK </h1> 
<h1><center> Tambah Data Mahasiswa </h1>
<body style="background-color:#b3ccff">

<?php echo form_open('mahasiswa/create');?>
<table align="center">
    <tr><td>NIM</td><td><?php echo form_input('nim');?></td></tr>
    <tr><td>NAMA</td><td><?php echo form_input('nama');?></td></tr>
    <tr><td>PRODI</td><td><?php echo form_input('prodi');?></td></tr>
	<tr><td>ALAMAT</td><td><?php echo form_input('alamat');?></td></tr>
    <tr><td colspan="2" align="center">
        <?php echo form_submit('submit','Simpan');?>
        <?php echo anchor('mahasiswa','Kembali');?></td></tr>
</table>
<?php
echo form_close();
?>

<h4 style="background-color:DodgerBlue" align="center">Listyani Praptining P (15.01.53.0013) <br> Apriana Panca K (15.01.53.0065) <br> Fadilla Maulida (15.01.53.0082)</h4> 
</body> </center>
</html>