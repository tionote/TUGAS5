<html>
<title> Data Dosen </title>
<h1 style="background-color:DodgerBlue" align="center">UNIVERSITAS STIKUBANK SEMARANG <br> TAHUN PELAJARAN 2018 <br> SISTEM INFORMASI AKADEMIK </h1> 

<body style="background-color:#b3ccff">

<center><h2>DATA MAHASISWA UNIVERSITAS STIKUBANK</h2>
<h3>TAHUN AJARAN 2017/2018</h3></center><br>
<?php echo form_open('dosen/create');?>
<table border=1 align=center>
    <tr><td>NIP</td><td><?php echo form_input('nip');?></td></tr>
    <tr><td>NAMA</td><td><?php echo form_input('nama');?></td></tr>
    <tr><td>MATAK KULIAH</td><td><?php echo form_input('matakuliah');?></td></tr>
    <tr><td colspan="2">
        <?php echo form_submit('submit','Simpan');?>
        <?php echo anchor('dosen','Kembali');?></td></tr>
</table>
<?php
echo form_close();
?>
<h4 style="background-color:DodgerBlue" align="center">Listyani Praptining P (15.01.53.0013) <br> Apriana Panca K (15.01.53.0065) <br> Fadilla Maulida (15.01.53.0082)</h4> 
</body> </center>
</html>