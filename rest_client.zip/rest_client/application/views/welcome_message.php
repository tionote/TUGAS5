<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Rest Client</title>

	<style type="text/css">

.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}

.upload {background-color: #f44336;} 
.upload:hover {background: #da190b;}

.token {background-color: #ff9800;} 
.token:hover {background: #e68a00;}

.stem {background-color: #4CAF50;} 
.stem:hover {background: #46a049;}

.cariquery {background-color: #f44336;} 
.cariquery:hover {background: #da190b;}

.query {background-color: #ff9800;} 
.query:hover {background: #e68a00;}

.bobot {background-color: #4CAF50;} 
.bobot:hover {background: #46a049;}

	</style>
</head>

<body style="background-color:#b3ccff">

<center> 
<h1 style="background-color:DodgerBlue">UNIVERSITAS STIKUBANK SEMARANG <br> TAHUN PELAJARAN 2018 <br> SISTEM INFORMASI AKADEMIK </h1> 
<br>
<input type="button" value="DATA MAHASISWA" onclick="window.open('<?php echo site_url('mahasiswa'); ?>')" button class="btn upload">  </button> <br> <br>
<input type="button" value="DATA DOSEN" onclick="window.open('<?php echo site_url('dosen'); ?>')" button class="btn stem">  </button> <br> <br>
<input type="button" value="DATA MATAKULIAH" onclick="window.open('<?php echo site_url('matakuliah'); ?>')" button class="btn token">  </button> <br> <br>
<input type="button" value="DATA KRS" onclick="window.open('<?php echo site_url('krs'); ?>')" button class="btn cariquery">  </button> <br> <br>

<h4 style="background-color:DodgerBlue">Listyani Praptining P (15.01.53.0013) <br> Apriana Panca K (15.01.53.0065) <br> Fadilla Maulida (15.01.53.0082)</h4> 
<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</center>


</center><br/>
<br/>
<br/>
<br/>
<br/>


</body>
</html>